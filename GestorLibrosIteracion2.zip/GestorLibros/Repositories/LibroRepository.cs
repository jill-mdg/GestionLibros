﻿using GestorLibros.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestorLibros.Repositories
{
    public class LibroRepository : RepositoryBase, ILibroRepository
    {
        public string Add(LibroModel libro)
        {
            if (libro == null) throw new ArgumentNullException(nameof(libro));
            if (string.IsNullOrWhiteSpace(libro.ISBN)) throw new ArgumentException("ISBN no puede estar vacío.");
            if (string.IsNullOrWhiteSpace(libro.Titulo)) throw new ArgumentException("Titulo no puede estar vacío.");
            if (string.IsNullOrWhiteSpace(libro.Autor)) throw new ArgumentException("Autor no puede estar vacío.");
            if (string.IsNullOrWhiteSpace(libro.Formato)) throw new ArgumentException("Formato no puede estar vacío.");
            if (string.IsNullOrWhiteSpace(libro.Tipo)) throw new ArgumentException("Tipo no puede estar vacío.");

            if (string.IsNullOrWhiteSpace(libro.Id))
                libro.Id = Guid.NewGuid().ToString();

            if (!Guid.TryParse(libro.Id, out var guidId))
                throw new ArgumentException("El Id del libro no es un GUID válido.");

            if (libro.Creado == default) libro.Creado = DateTime.UtcNow;

            using (var conn = GetConnection())
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = @"
                    INSERT INTO LibrosTable
                    (Id, ISBN, Titulo, Autor, PortadaPath, PortadaMime, Formato, Tipo, Creado, Actualizado)
                    VALUES
                    (@Id, @ISBN, @Titulo, @Autor, @PortadaPath, @PortadaMime, @Formato, @Tipo, @Creado, @Actualizado);
                ";

                cmd.Parameters.Add("@Id", SqlDbType.UniqueIdentifier).Value = guidId;
                cmd.Parameters.Add("@ISBN", SqlDbType.NVarChar, 50).Value = libro.ISBN;
                cmd.Parameters.Add("@Titulo", SqlDbType.NVarChar).Value = (object)libro.Titulo ?? DBNull.Value;
                cmd.Parameters.Add("@Autor", SqlDbType.NVarChar).Value = (object)libro.Autor ?? DBNull.Value;


                cmd.Parameters.Add("@PortadaPath", SqlDbType.NVarChar, 50).Value =
                    (object)libro.PortadaPath ?? DBNull.Value;
                cmd.Parameters.Add("@PortadaMime", SqlDbType.NVarChar, 50).Value =
                    (object)libro.PortadaMime ?? DBNull.Value;

                cmd.Parameters.Add("@Formato", SqlDbType.NVarChar, 50).Value = libro.Formato;
                cmd.Parameters.Add("@Tipo", SqlDbType.NVarChar, 50).Value = libro.Tipo;

                cmd.Parameters.Add("@Creado", SqlDbType.DateTime).Value = libro.Creado;
                cmd.Parameters.Add("@Actualizado", SqlDbType.DateTime).Value =
                    libro.Actualizado.HasValue ? (object)libro.Actualizado.Value : (object)DBNull.Value;

                cmd.ExecuteNonQuery();
                conn.Close();
            }

            return libro.Id;
        }

        public void Update(LibroModel libro)
        {
            if (libro == null) throw new ArgumentNullException(nameof(libro));
            if (string.IsNullOrWhiteSpace(libro.Id) || !Guid.TryParse(libro.Id, out var guidId))
                throw new ArgumentException("Id inválido.");

            // establecer fecha de actualización
            libro.Actualizado = DateTime.UtcNow;

            using (var connection = GetConnection())
            using (var command = new SqlCommand())
            {
                connection.Open();
                command.Connection = connection;
                command.CommandText = @"
                    UPDATE LibrosTable
                    SET
                        ISBN = @ISBN,
                        Titulo = @Titulo,
                        Autor = @Autor,
                        PortadaPath = @PortadaPath,
                        PortadaMime = @PortadaMime,
                        Formato = @Formato,
                        Tipo = @Tipo,
                        Actualizado = @Actualizado
                    WHERE Id = @Id;
                ";

                command.Parameters.Add("@ISBN", SqlDbType.NVarChar, 50).Value = libro.ISBN;
                command.Parameters.Add("@Titulo", SqlDbType.NVarChar).Value = (object)libro.Titulo ?? DBNull.Value;
                command.Parameters.Add("@Autor", SqlDbType.NVarChar).Value = (object)libro.Autor ?? DBNull.Value;
                command.Parameters.Add("@PortadaPath", SqlDbType.NVarChar, 50).Value =
                    (object)libro.PortadaPath ?? DBNull.Value;
                command.Parameters.Add("@PortadaMime", SqlDbType.NVarChar, 50).Value =
                    (object)libro.PortadaMime ?? DBNull.Value;
                command.Parameters.Add("@Formato", SqlDbType.NVarChar, 50).Value = libro.Formato;
                command.Parameters.Add("@Tipo", SqlDbType.NVarChar, 50).Value = libro.Tipo;
                command.Parameters.Add("@Actualizado", SqlDbType.DateTime).Value = libro.Actualizado;
                command.Parameters.Add("@Id", SqlDbType.UniqueIdentifier).Value = guidId;

                command.ExecuteNonQuery();
                connection.Close();
            }
        }

        public void Delete(LibroModel libroModel)
        {
            if (libroModel == null) throw new ArgumentNullException(nameof(libroModel));
            if (string.IsNullOrWhiteSpace(libroModel.Id) || !Guid.TryParse(libroModel.Id, out var guidId))
                throw new ArgumentException("Id inválido.");

            using (var conn = GetConnection())
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = "DELETE FROM LibrosTable WHERE Id = @Id";
                cmd.Parameters.Add("@Id", SqlDbType.UniqueIdentifier).Value = guidId;
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public LibroModel GetById(string id)
        {
            if (string.IsNullOrWhiteSpace(id) || !Guid.TryParse(id, out var guidId))
                return null;

            using (var conn = GetConnection())
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT Id, ISBN, Titulo, Autor, PortadaPath, PortadaMime, Formato, Tipo, Creado, Actualizado
                    FROM LibrosTable
                    WHERE Id = @Id
                ";
                cmd.Parameters.Add("@Id", SqlDbType.UniqueIdentifier).Value = guidId;
                conn.Open();

                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var libro = new LibroModel
                        {
                            Id = reader["Id"].ToString(),
                            ISBN = reader["ISBN"]?.ToString(),
                            Titulo = reader["Titulo"]?.ToString(),
                            Autor = reader["Autor"]?.ToString(),
                            PortadaPath = reader["PortadaPath"] == DBNull.Value ? null : reader["PortadaPath"].ToString(),
                            PortadaMime = reader["PortadaMime"] == DBNull.Value ? null : reader["PortadaMime"].ToString(),
                            Formato = reader["Formato"]?.ToString(),
                            Tipo = reader["Tipo"]?.ToString(),
                            Creado = reader["Creado"] == DBNull.Value ? default : Convert.ToDateTime(reader["Creado"]),
                            Actualizado = reader["Actualizado"] == DBNull.Value ? default : Convert.ToDateTime(reader["Actualizado"])
                        };
                        return libro;
                    }
                }
            }

            return null;
        }
    }
}
