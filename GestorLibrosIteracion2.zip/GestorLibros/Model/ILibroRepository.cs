﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestorLibros.Model
{
    public interface ILibroRepository
    {
            
        string Add(LibroModel libroModel);
        void Update(LibroModel libroModel);
        void Delete(LibroModel libroModel);
    }

}
