﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestorLibros.Model
{
    public class LibroModel
    {
        public string Id { get; set; }
        public string ISBN { get; set; }
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public string PortadaPath { get; set; }
        public string PortadaMime { get; set; }
        public string Formato { get; set; }
        public string Tipo { get; set; }
        public string Ubicacion { get; set; }
        public DateTime Creado { get; set; }
        public DateTime? Actualizado { get; set; }
    }
}
