﻿using GestorLibros.ViewModel;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GestorLibros.View
{
    /// <summary>
    /// Interaction logic for EditarLibro.xaml
    /// </summary>
    public partial class EditarLibroView : Window
    {
        private readonly EditarLibroViewModel _vm;
        public EditarLibroView()
        {
            InitializeComponent();
            _vm = new EditarLibroViewModel();  
            this.DataContext = _vm;
        }

        private void BtnAgregarImg_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog();
            dlg.Filter = "Image files |*.jpg; *.png;*.jpeg;*.bmp;*.webp";
            if (dlg.ShowDialog() != true) return;

            string sourceFile = dlg.FileName;
            try
            {
                var imagesFolder = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "MiGestorLibros", "covers");
                Directory.CreateDirectory(imagesFolder);

                var ext = System.IO.Path.GetExtension(sourceFile);
                var filename = Guid.NewGuid().ToString() + ext;
                var destPath = System.IO.Path.Combine(imagesFolder, filename);

                if (!File.Exists(destPath))
                    File.Copy(sourceFile, destPath);


                var vm = this.DataContext as EditarLibroViewModel ?? _vm;
                if (vm == null)
                {
                    MessageBox.Show("ViewModel no disponible.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }


                vm.PortadaPath = destPath;

                string mime = "application/octet-stream";
                var lower = ext?.ToLowerInvariant();
                if (lower == ".jpg" || lower == ".jpeg") mime = "image/jpeg";
                else if (lower == ".png") mime = "image/png";
                else if (lower == ".bmp") mime = "image/bmp";
                else if (lower == ".webp") mime = "image/webp";

                vm.PortadaMime = mime;

                if (vm.Libro == null) vm.Libro = new GestorLibros.Model.LibroModel();
                vm.Libro.PortadaPath = destPath;
                vm.Libro.PortadaMime = mime;

                // DEBUG 
                System.Diagnostics.Debug.WriteLine($"Copied to: {destPath} Exists: {File.Exists(destPath)} VM.PortadaPath: {vm.PortadaPath}");
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo agregar la imagen: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

    }
}
