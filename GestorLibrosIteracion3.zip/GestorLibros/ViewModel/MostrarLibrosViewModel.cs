﻿using GestorLibros.Model;
using GestorLibros.Repositories;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace GestorLibros.ViewModel
{
    public class MostrarLibrosViewModel: ViewModelBase
    {
        private readonly LibroRepository _libroRepository;
        private ObservableCollection<LibroModel> _allLibros;
        private ObservableCollection<LibroModel> _lastTwelveBooks;
        private const int MaxDisplayCount = 12;

        private LibroModel _selectedLibro;

        public ICommand AddCommand { get; }
        public ICommand EditCommand { get; }

        public ObservableCollection<LibroModel> LastTwelveBooks
        {
            get => _lastTwelveBooks;
            set
            {
                _lastTwelveBooks = value;
                OnPropertyChanged(nameof(LastTwelveBooks));
            }
        }

        public ObservableCollection<LibroModel> Libros
        {
            get => _allLibros;
            set
            {
                if (_allLibros != null)
                    _allLibros.CollectionChanged -= AllLibros_CollectionChanged;

                _allLibros = value;

                if (_allLibros != null)
                    _allLibros.CollectionChanged += AllLibros_CollectionChanged;

                OnPropertyChanged(nameof(Libros));
                UpdateLastTwelve();
            }
        }

        public LibroModel SelectedLibro
        {
            get => _selectedLibro;
            set
            {
                _selectedLibro = value;
                OnPropertyChanged(nameof(SelectedLibro));
                CommandManager.InvalidateRequerySuggested();
            }
        }

        public MostrarLibrosViewModel()
        {
            _libroRepository = new LibroRepository();
            AddCommand = new ViewModelCommand(ExecuteAddLibro);
            EditCommand = new ViewModelCommand(ExecuteEditLibro, CanExecuteEditLibro);

            LoadData();
        }

        private void AllLibros_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            UpdateLastTwelve();
        }

        public void LoadData()
        {
            var recent = _libroRepository.GetRecent(MaxDisplayCount) ?? new System.Collections.Generic.List<LibroModel>();
            Libros = new ObservableCollection<LibroModel>(recent);
            UpdateLastTwelve();
        }

        private void UpdateLastTwelve()
        {
            if (_allLibros == null)
            {
                LastTwelveBooks = new ObservableCollection<LibroModel>();
                return;
            }

            var sorted = _allLibros
                .OrderByDescending(l =>
                    (l.Actualizado != default(DateTime) && l.Actualizado > l.Creado) ? l.Actualizado : l.Creado)
                .Take(MaxDisplayCount)
                .ToList();

            LastTwelveBooks = new ObservableCollection<LibroModel>(sorted);
            CommandManager.InvalidateRequerySuggested();
        }


        private void ExecuteAddLibro(object obj)
        {
            var editarView = new View.EditarLibroView();
            var editarVm = new EditarLibroViewModel();
            editarView.DataContext = editarVm;

            Application.Current.MainWindow = editarView;
            editarView.Show();

            foreach (Window window in Application.Current.Windows.OfType<Window>().ToList())
            {
                if (window != editarView)
                    window.Close();
            }

            editarView.Closed += (s, e) => LoadData();
        }

        private bool CanExecuteEditLibro(object param)
        {
            var libro = param as LibroModel ?? SelectedLibro;
            return libro != null;
        }

        private void ExecuteEditLibro(object param)
        {
            var selected = param as LibroModel ?? SelectedLibro;
            if (selected == null)
            {
                MessageBox.Show("Selecciona un libro para editar.", "Atención", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var editModel = new LibroModel
            {
                Id = selected.Id,
                ISBN = selected.ISBN,
                Titulo = selected.Titulo,
                Autor = selected.Autor,
                PortadaPath = selected.PortadaPath,
                PortadaMime = selected.PortadaMime,
                Formato = selected.Formato,
                Tipo = selected.Tipo,
                Creado = selected.Creado,
                Actualizado = selected.Actualizado
            };

            var editarView = new View.EditarLibroView();
            var editarVm = new EditarLibroViewModel();
            editarVm.LoadFromModel(editModel);
            editarView.DataContext = editarVm;

            Application.Current.MainWindow = editarView;
            editarView.Show();

            foreach (Window window in Application.Current.Windows.OfType<Window>().ToList())
            {
                if (window != editarView)
                    window.Close();
            }

            editarView.Closed += (s, e) => LoadData();
        }
    }

}
