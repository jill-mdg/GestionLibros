﻿using GestorLibros.Model;
using GestorLibros.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace GestorLibros.ViewModel
{
    public class EditarLibroViewModel : ViewModelBase
    {
        private readonly ILibroRepository _libroRepository;
        private bool _isSaving = false;

        private string _titulo;
        private string _isbn;
        private string _autor;
        private string _formato;
        private string _tipo;
        private string _ubicacion;     
        private string _portadaPath;
        private string _portadaMime;

        public ICommand SaveCommand { get; }
        public ICommand DeleteCommand {  get; }

        public string Titulo
        {
            get => _titulo;
            set
            {
                if (_titulo == value) return;
                _titulo = value;
                OnPropertyChanged(nameof(Titulo));
                CommandManager.InvalidateRequerySuggested();
            }
        }

        public string ISBN
        {
            get => _isbn;
            set
            {
                if (_isbn == value) return;
                _isbn = value;
                OnPropertyChanged(nameof(ISBN));
            }
        }

        public string Autor
        {
            get => _autor;
            set
            {
                if (_autor == value) return;
                _autor = value;
                OnPropertyChanged(nameof(Autor));
            }
        }

        public string Formato
        {
            get => _formato;
            set
            {
                if (_formato == value) return;
                _formato = value;
                OnPropertyChanged(nameof(Formato));
            }
        }

        public string Tipo
        {
            get => _tipo;
            set
            {
                if (_tipo == value) return;
                _tipo = value;
                OnPropertyChanged(nameof(Tipo));
            }
        }

        public string Ubicacion
        {
            get => _ubicacion;
            set
            {
                if (_ubicacion == value) return;
                _ubicacion = value;
                OnPropertyChanged(nameof(Ubicacion));
            }
        }

        public string PortadaPath
        {
            get => _portadaPath;
            set
            {
                if (_portadaPath == value) return;
                _portadaPath = value;
                OnPropertyChanged(nameof(PortadaPath));
            }
        }

        public string PortadaMime
        {
            get => _portadaMime;
            set
            {
                if (_portadaMime == value) return;
                _portadaMime = value;
                OnPropertyChanged(nameof(PortadaMime));
            }
        }

        public LibroModel Libro { get; set; }

        public EditarLibroViewModel()
        {
            _libroRepository = new LibroRepository();

            SaveCommand = new ViewModelCommand(ExecuteSave, CanExecuteSave);
            DeleteCommand = new ViewModelCommand(ExecuteDelete, CanExecuteDelete);
        }

        public void LoadFromModel(LibroModel model)
        {
            if (model == null) return;
            Libro = model;

            Titulo = model.Titulo;
            ISBN = model.ISBN;
            Autor = model.Autor;
            Formato = model.Formato;
            Tipo = model.Tipo;
            PortadaPath = model.PortadaPath;
            PortadaMime = model.PortadaMime;

        }

        private bool CanExecuteSave(object obj)
        {

            return !string.IsNullOrWhiteSpace(Titulo) && !_isSaving;
        }

        private void ExecuteSave(object obj)
        {
            if (_isSaving) return;
            _isSaving = true;

            try
            {
                if (string.IsNullOrWhiteSpace(Titulo))
                {
                    MessageBox.Show("El título es obligatorio.", "Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (Libro == null)
                    Libro = new LibroModel();

                Libro.Titulo = Titulo;
                Libro.ISBN = ISBN;
                Libro.Autor = Autor;
                Libro.Formato = Formato;
                Libro.Tipo = Tipo;
                Libro.Ubicacion = Ubicacion;
                Libro.PortadaPath = PortadaPath;
                Libro.PortadaMime = PortadaMime;

                if (string.IsNullOrWhiteSpace(Libro.Id))
                {
                    Libro.Id = Guid.NewGuid().ToString();
                    Libro.Creado = DateTime.UtcNow;

                    var newId = _libroRepository.Add(Libro);
                    Libro.Id = newId;
                    MessageBox.Show("Libro guardado correctamente.", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {

                    Libro.Actualizado = DateTime.UtcNow;
                    _libroRepository.Update(Libro);
                    MessageBox.Show("Libro actualizado correctamente.", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                }

                Titulo = string.Empty;
                ISBN = string.Empty;
                Autor = string.Empty;
                Formato = string.Empty;
                Tipo = string.Empty;
                PortadaPath = null;
                PortadaMime = null;
                Ubicacion = null;
                Libro = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar libro: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                _isSaving = false;
            }
        }
    
        private bool CanExecuteDelete(object obj)
        {
            OnPropertyChanged(nameof(Libro));
            CommandManager.InvalidateRequerySuggested();

            return !string.IsNullOrWhiteSpace(Libro?.Id);
        }

        private void ExecuteDelete(object obj)
        {
            try
            {
                if (Libro == null || string.IsNullOrWhiteSpace(Libro.Id))
                {
                    MessageBox.Show("No hay un libro válido seleccionado para eliminar.", "Atención", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var result = MessageBox.Show(
                    "¿Estás seguro que deseas eliminar este libro? Esta acción no se puede deshacer.",
                    "Confirmar eliminación",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result != MessageBoxResult.Yes)
                    return;

                _libroRepository.Delete(Libro);

                MessageBox.Show("Libro eliminado correctamente.", "Eliminado", MessageBoxButton.OK, MessageBoxImage.Information);

                var librosGeneral = Application.Current.Windows
                                        .OfType<Window>()
                                        .FirstOrDefault(w => w.GetType().Name == "LibrosGeneralView") as Window;

                if (librosGeneral == null)
                {
                    try
                    {
                        var tipo = Type.GetType("GestorLibros.View.LibrosGeneralView, " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name);
                        if (tipo != null)
                        {
                            librosGeneral = (Window)Activator.CreateInstance(tipo);
                        }
                    }
                    catch
                    {
                        librosGeneral = null;
                    }
                }

                if (librosGeneral != null)
                {
                    Application.Current.MainWindow = librosGeneral;
                    if (!librosGeneral.IsVisible)
                        librosGeneral.Show();
                    else
                        librosGeneral.Activate();
                }

                var windowsToClose = Application.Current.Windows
                                        .OfType<Window>()
                                        .Where(w => w != librosGeneral)
                                        .ToList();

                foreach (var w in windowsToClose)
                {
                    try { w.Close(); }
                    catch { }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar libro: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}

